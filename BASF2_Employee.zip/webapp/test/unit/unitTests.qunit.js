/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"basf/emp/details/BASF2_Employee/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});