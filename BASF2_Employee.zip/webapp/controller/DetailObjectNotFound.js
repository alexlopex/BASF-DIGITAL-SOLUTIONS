sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("basf.emp.details.BASF2_Employee.controller.DetailObjectNotFound", {});
});
